package frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class FrameBookInformation extends JPanel {

	public FrameBookInformation(Book b) {
		
		Color bgc = new Color(255, 241, 137);
		Color btc = new Color(184, 119, 249);
		
		setBackground(bgc);
		setLayout(null);
		setSize(600, 800);

		Font font1 = new Font("맑은고딕", Font.BOLD, 20);
		Font font2 = new Font("맑은고딕", Font.BOLD, 30);
		
		
		// 뒤로가기 버튼
		ImageIcon image2 = new ImageIcon("./src/back.png");
		Image img2 = image2.getImage();
    	Image updateImg2 = img2.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        ImageIcon updateIcon1 = new ImageIcon(updateImg2);
		JButton btnBack = new JButton(image2);
		btnBack.setIcon(updateIcon1);
		btnBack.setBorderPainted(false);
		btnBack.setBackground(bgc);
		btnBack.setBounds(10, 7, 50, 50);
		add(btnBack);
		
		btnBack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(b.getBookName() == "무지개 물고기" || b.getBookName() == "흥부와 놀부" || b.getBookName() == "아기돼지 삼형제" || b.getBookName() == "누가 내 머리에 똥 쌌어?") {
					
					FrameBase.getInstance(new FrameBookSelect1());	
				} else {
					FrameBase.getInstance(new FrameBookSelect2());
				}
			}
		});
		
		ImageIcon imageh = new ImageIcon("./src/home.png");
		Image imgh = imageh.getImage();
		Image updateImgh = imgh.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		ImageIcon updateIconh = new ImageIcon(updateImgh);
		JButton home = new JButton(imageh);
		home.setIcon(updateIconh);
		home.setBorderPainted(false);
		home.setContentAreaFilled(false);
		//home.setBackground(btc);
		home.setBounds(270, 700, 50, 50);
		add(home);
		
		home.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				FrameBase.getInstance(new FrameSelectAge());
				
			}
		});
		
		
		
		
		// 포스터 부분
				final int bookNum = 8;
				int bookflag = 0;
				String[] bookurl = { 
					"./src/fish.png", "./src/brother.png", "./src/head.png", 
					"./src/pig.png", "./src/prince.png", "./src/fox.png",
					"./src/alice.png", "./src/tree.png" };

				ImageIcon[] bookImg = new ImageIcon[bookNum];

				for (int i = 0; i < bookNum; i++) {	
					bookImg[i] = new ImageIcon( bookurl[i] );
					if (b.getBookName().equals("무지개 물고기")) {
						bookflag = 0;
					} else if (b.getBookName().equals("흥부와 놀부")) {
						bookflag = 1;
					} else if (b.getBookName().equals("누가 내 머리에 똥 쌌어?")) {
						bookflag = 2;
					} else if (b.getBookName().equals("아기돼지 삼형제")) {
						bookflag = 3;
					} else if (b.getBookName().equals("어린왕자")) {
						bookflag = 4;
					} else if (b.getBookName().equals("책 먹는 여우")) {
						bookflag = 5;
					} else if (b.getBookName().equals("이상한 나라의 앨리스")) {
						bookflag = 6;
					} else if (b.getBookName().equals("아낌없이 주는 나무")) {
						bookflag = 7;
					}
				}
		
		
		ImageIcon icon = new ImageIcon(bookImg[bookflag].getImage().getScaledInstance(140, 220, Image.SCALE_SMOOTH));
		JLabel jl = new JLabel(icon);
		jl.setBounds(20, 60, 140, 220);
		add(jl);
		
		
		//책 제목
		JLabel bName = new JLabel(b.getBookName());
		bName.setHorizontalAlignment(JLabel.CENTER);
		bName.setBounds(160, 50, 400, 90);
		bName.setFont(font2);
		add(bName);

		//저자
		JLabel cName = new JLabel(b.getBookPub());
		cName.setHorizontalAlignment(JLabel.CENTER);
		cName.setBounds(160, 150, 400, 90);
		cName.setFont(font1);
		add(cName);

		//출판사
		JLabel bDate = new JLabel(b.getBookCop());
		bDate.setHorizontalAlignment(JLabel.CENTER);
		bDate.setBounds(160, 195, 400, 90);
		bDate.setFont(font1);
		add(bDate);
			

		//책 소개
		JLabel bin = new JLabel("책 소개");
		bin.setHorizontalAlignment(JLabel.CENTER);
		bin.setBounds(20, 220, 560, 200);
		bin.setFont(font2);
		add(bin);

		//책 소개글s
		JTextArea bi = new JTextArea(b.getBookInt());

		JScrollPane sP = new JScrollPane(bi, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		bi.setLineWrap(true);
		bi.setFont(new Font("맑은고딕", Font.BOLD, 15));
		sP.setBounds(20, 350, 540, 120);
		setVisible(true);
		add(sP);

		//퀴즈버튼
		JButton btnQ = new JButton("퀴즈 풀러가기");
		btnQ.setBorderPainted(false);
		btnQ.setFocusPainted(false);
		btnQ.setBounds(20, 520, 540, 80);
		btnQ.setBackground(new Color(184, 119, 249));
		btnQ.setFont(new Font("맑은고딕", Font.BOLD, 30));
		add(btnQ);

		//독후감 버튼
		JButton btnD = new JButton("독후감 쓰러가기");
		btnD.setBorderPainted(false);
		btnD.setFocusPainted(false);
		btnD.setBounds(20, 620, 540, 80);
		btnD.setBackground(new Color(184, 119, 249));
		btnD.setFont(new Font("맑은고딕", Font.BOLD, 30));
		add(btnD);

		btnBack.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});	
		
		btnQ.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				FrameBase.getInstance(new FrameQuiz1(b));
				
			}
		});
		
		 btnD.addActionListener(new ActionListener() {
	         
	         @Override
	         public void actionPerformed(ActionEvent e) {
	            FrameBase.getInstance(new BookReviewPage(b));
	            
	         }
	      });
		

	}

}
