package frame;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FrameMyPage extends JPanel{

	public FrameMyPage() {
		setBackground(new Color(169, 169, 169));
		setLayout(null);
		setSize(600, 800);
		
		JPanel myPageMenu = new JPanel();
		myPageMenu.setBackground(new Color(255, 255, 255));
		myPageMenu.setSize(450, 800);
		myPageMenu.setLocation(150, 0);
		myPageMenu.setLayout(null);
		
		add(myPageMenu);
		
		//메뉴바
		ImageIcon hamberger = new ImageIcon("./src/hamBtn_w.png");
		JLabel jLabel2 = new JLabel(hamberger); 
		jLabel2.setSize(50, 50);
		jLabel2.setLocation(10,5);
		myPageMenu.add(jLabel2);
		
		//즐겨찾기 
		JPanel panelHeart = new JPanel();
		panelHeart.setSize(450, 80);
		panelHeart.setBackground(new Color(255, 255, 255));
		panelHeart.setLocation(0, 115);
		panelHeart.setLayout(null);
		myPageMenu.add(panelHeart);
		
		//내가 쓴 독서록
		JPanel panelBoard = new JPanel();
		panelBoard.setSize(450, 80);
		panelBoard.setBackground(new Color(255, 255, 255));
		panelBoard.setLocation(0, 197);
		panelBoard.setLayout(null);
		myPageMenu.add(panelBoard);
		
		//구매하기
		JPanel panelBuy = new JPanel();
		panelBuy.setSize(450, 80);
		panelBuy.setBackground(new Color(255, 255, 255));
		panelBuy.setLocation(0, 279);
		panelBuy.setLayout(null);
		myPageMenu.add(panelBuy);
		
		//마이페이지
		JPanel panelMyPage = new JPanel();
		panelMyPage.setSize(450, 80);
		panelMyPage.setBackground(new Color(255, 255, 255));
		panelMyPage.setLocation(0, 361);
		panelMyPage.setLayout(null);
		myPageMenu.add(panelMyPage);
		
		//즐겨찾기 이미지
		ImageIcon heart = new ImageIcon("./src/heart.png");
		JLabel jHeart = new JLabel(heart); 
		jHeart.setSize(70, 70);
		jHeart.setLocation(5,3);
		panelHeart.add(jHeart);
		
		
		JLabel labelHeart = new JLabel("즐겨찾기");
		labelHeart.setSize(300, 50);
		labelHeart.setLocation(100, 10);
		labelHeart.setFont(new Font("맑은고딕", Font.BOLD, 20));
		panelHeart.add(labelHeart);
		
		//구분선1
		JPanel jHorizon1 = new JPanel();
		jHorizon1.setSize(450, 1);
		jHorizon1.setLocation(0, 195);
		jHorizon1.setBackground(Color.lightGray);
		myPageMenu.add(jHorizon1);
		
		//구분선2
		JPanel jHorizon2 = new JPanel();
		jHorizon2.setSize(450, 1);
		jHorizon2.setLocation(0, 277);
		jHorizon2.setBackground(Color.lightGray);
		myPageMenu.add(jHorizon2);
		
		//구분선3
		JPanel jHorizon3 = new JPanel();
		jHorizon3.setSize(450, 1);
		jHorizon3.setLocation(0, 359);
		jHorizon3.setBackground(Color.lightGray);
		myPageMenu.add(jHorizon3);
		
		//내가 쓴 독서록 이미지
		ImageIcon board = new ImageIcon("./src/noticeboard.png");
		JLabel jBoard = new JLabel(board); 
		jBoard.setSize(70, 70);
		jBoard.setLocation(5,3);
		panelBoard.add(jBoard);
		
		JLabel labelBoard = new JLabel("내가 쓴 독서록");
		labelBoard.setSize(300, 50);
		labelBoard.setLocation(100, 10);
		labelBoard.setFont(new Font("맑은고딕", Font.BOLD, 20));
		panelBoard.add(labelBoard);
		
		//구매하기 이미지
		ImageIcon buy = new ImageIcon("./src/book.png");
		JLabel jBuy = new JLabel(buy); 
		jBuy.setSize(70, 70);
		jBuy.setLocation(5,3);
		panelBuy.add(jBuy);
		
		JLabel labelBuy = new JLabel("구매하기");
		labelBuy.setSize(300, 50);
		labelBuy.setLocation(100, 10);
		labelBuy.setFont(new Font("맑은고딕", Font.BOLD, 20));
		panelBuy.add(labelBuy);
		
		//마이페이지 이미지
		ImageIcon my = new ImageIcon("./src/user.png");
		JLabel jMy = new JLabel(my); 
		jMy.setSize(70, 70);
		jMy.setLocation(5,3);
		panelMyPage.add(jMy);
		
		JLabel labelMy = new JLabel("마이 페이지");
		labelMy.setSize(300, 50);
		labelMy.setLocation(100, 10);
		labelMy.setFont(new Font("맑은고딕", Font.BOLD, 20));
		panelMyPage.add(labelMy);
		
		
		
		
		
	}
}
