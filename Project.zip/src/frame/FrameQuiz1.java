package frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FrameQuiz1 extends JPanel {

	public static int rightNum1 = 0;
	
	public FrameQuiz1(Book b) {

    	//String text = "<html><br>앨리스가 이상한 나라에서 크기를 <br>조절할 수 있는 물건은 초콜릿입니다.</html>";
    	setBackground(new Color(255, 241, 137));
        setLayout(null); 
        setSize(600, 800);
        
        
        for(int i=0; i<8; i++) {
        	if(b.getBookName().equals("무지개 물고기")) {
        		Book bookQ = new Book("무지개 물고기", "<html><br>무지개 물고기는 산호초 아저씨를 <br>찾아갔습니다.<html>",
        		   		 "<html><br>무지개 물고기는 하루에 한 번 <br>무지개를 만듭니다.<html>",
        		   		 "<html><br>무지개 물고기는 친구들에게 <br>비늘을 나눠주었습니다.<html>",
        		   		"X", "X", "O");
        		b = bookQ;
        	}else if(b.getBookName().equals("흥부와 놀부")) {
        		Book bookQ = new Book("흥부와 놀부", "<html><br>놀부는 까마귀 다리를 고쳐주고 <br>박을 얻었습니다.<html>", 
			   "<html><br>흥부의 자식은 1명 입니다.<html>", 
			   "<html><br>흥부는 박을 타서 금은보화를 얻었습니다.<html>", 
			   "X", "X", "O");
        		b = bookQ;
        	}else if(b.getBookName().equals("누가 내 머리에 똥 쌌어?")) {
        		Book bookQ = new Book("누가 내 머리에 똥 쌌어?", "<html><br>이 책의 주인공은 두더지입니다.<html>", 
			   "<html><br>두더지는 머리에 똥 싼 범인을 <br>찾기 위해 뱀에게 물어봤습니다.<html>", 
			   "<html><br>두더지는 파리의 도움으로 <br>똥 싼 범인을 찾게 됩니다.<html>", 
			   "O", "X", "O");
        		b = bookQ;
        	}else if(b.getBookName().equals("아기돼지 삼형제")) {
        		Book bookQ = new Book("아기돼지 삼형제", "<html><br>첫째 돼지는 벽돌로 집을 지었습니다.<html>", 
        				   "<html><br>둘째 돼지의 집을 부순건 코끼리입니다.<html>",
        				   "<html><br>둘째돼지와 셋째돼지는<br> 늑대에게 잡아먹혔니다.<html>",  
        				   "X", "X", "X");
        		b = bookQ;
        	}else if(b.getBookName().equals("어린왕자")) {
        		Book bookQ = new Book("어린왕자", "<html><br>어린왕자는 여우에게 양을 <br>그려달라고 부탁합니다.<html>", 
        				   "<html><br>어린왕자는 가로등을 켜는 사람(점등인)을 <br>바보같다고 놀립니다.<html>", 
        				   "<html><br>장미꽃은 어린왕자를 대하는 것에 <br>서툴러했습니다.<html>", 
        				   "X", "X", "O");
        		b = bookQ;
        	}else if(b.getBookName().equals("책 먹는 여우")) {
        		Book bookQ = new Book("책 먹는 여우", "<html><br>여우 아저씨는 책을 먹는걸 좋아합니다.<html>", 
        				   "<html><br>여우 아저씨는 도서관 책을 먹어서 <br>사람들에게 칭찬을 들었습니다.<html>", 
        				   "<html><br>여우 아저씨는 베스트셀러 작가가 <br>되는게 꿈이었습니다.<html>", 
        				   "O", "X", "X");
        		b = bookQ;
        	}else if(b.getBookName().equals("이상한 나라의 앨리스")) {
        		Book bookQ = new Book("이상한 나라의 앨리스", "<html><br>앨리스가 토끼굴로 떨어지게 된 <br>계기는 앨리스의 꿈이었다.<html>", 
        				   "<html><br>이상한 나라의 여왕이 좋아하는 <br>카드 게임은 포커입니다.<html>", 
        				   "<html><br>앨리스가 이상한 나라에서 크기를 <br>조절할 수 있는 물건은 초콜릿입니다.<html>", 
        				   "O", "O", "X");
        		b = bookQ;
        	}else if(b.getBookName().equals("아낌없이 주는 나무")) {
        		Book bookQ = new Book("아낌없이 주는 나무", "<html><br>소년은 나무의 사과를 팔아 <br>돈을 벌었습니다.<html>", 
        				   "<html><br>소년은 나무 그네 타는 것을 <br>싫어했습니다.<html>", 
        				   "<html><br>나무는 소년이 점점 싫어졌습니다.<html>", 
        				   "O", "X", "X");
        		b = bookQ;
        	}
        	
        }

     // RoundedPanel 퀴즈 질문
        RoundedPanel panel = new RoundedPanel(new Color(255, 255, 255), b.getQuestion1(), 18);
        panel.setSize(400, 100); 
        panel.setLocation(100, 150); 
        System.out.println(b.getQuestion1());
        add(panel);
        
        // X, O 버튼
        ImageIcon wrong = new ImageIcon("./src/x.png");
        Image wrongImg = wrong.getImage();
        Image updatewrongImg = wrongImg.getScaledInstance(100,  113, Image.SCALE_SMOOTH);
        ImageIcon updateWrong = new ImageIcon(updatewrongImg);
        JButton btnWrong = new JButton(wrong);
        btnWrong.setIcon(updateWrong);
        btnWrong.setBorderPainted(false);
        btnWrong.setBackground(new Color(255, 241, 137));
        btnWrong.setBounds(150, 300, 100, 113);
        add(btnWrong);
        
		ImageIcon right = new ImageIcon("./src/o.png");
		Image rightImg = right.getImage();
		Image updaterightImg = rightImg.getScaledInstance(100,  113, Image.SCALE_SMOOTH);
		ImageIcon updateRight = new ImageIcon(updaterightImg);
        JButton btnRight = new JButton(right);
        btnRight.setIcon(updateRight);
        btnRight.setBorderPainted(false);
        btnRight.setBackground(new Color(255, 241, 137));
        btnRight.setBounds(330, 300, 100, 113);
        add(btnRight);
        
		//퀴즈1
        ImageIcon quiz1 = new ImageIcon("./src/QuizBtn.png");
        Image quiz1Img = quiz1.getImage();
		Image updatequiz1Img = quiz1Img.getScaledInstance(32,  32, Image.SCALE_SMOOTH);
		ImageIcon updateQuiz1 = new ImageIcon(updatequiz1Img);
        JButton btnQuiz1 = new JButton(quiz1);
        btnQuiz1.setIcon(updateQuiz1);
        btnQuiz1.setBorderPainted(false);
        btnQuiz1.setBackground(new Color(255, 241, 137));
        btnQuiz1.setBounds(190, 620, 32, 32);
        add(btnQuiz1);
        
        //퀴즈2
        ImageIcon quiz2 = new ImageIcon("./src/QuizBtn.png");
        Image quiz2Img = quiz2.getImage();
		Image updatequiz2Img = quiz2Img.getScaledInstance(32,  32, Image.SCALE_SMOOTH);
		ImageIcon updateQuiz2 = new ImageIcon(updatequiz2Img);
        JButton btnQuiz2 = new JButton(quiz2);
        btnQuiz2.setIcon(updateQuiz2);
        btnQuiz2.setBorderPainted(false);
        btnQuiz2.setBackground(new Color(255, 241, 137));
        btnQuiz2.setBounds(275, 620, 32, 32);
        add(btnQuiz2);
        
        //퀴즈3
        ImageIcon quiz3 = new ImageIcon("./src/QuizBtn.png");
        Image quiz3Img = quiz1.getImage();
		Image updatequiz3Img = quiz3Img.getScaledInstance(32,  32, Image.SCALE_SMOOTH);
		ImageIcon updateQuiz3 = new ImageIcon(updatequiz3Img);
        JButton btnQuiz3 = new JButton(quiz3);
        btnQuiz3.setIcon(updateQuiz3);
        btnQuiz3.setBorderPainted(false);
        btnQuiz3.setBackground(new Color(255, 241, 137));
        btnQuiz3.setBounds(360, 620, 32, 32);
        add(btnQuiz3);
        
        
        //정답
        JLabel answer = new JLabel("정답:  " + b.getAnswer1());
        answer.setSize(100, 50);
        answer.setLocation(250, 500);
		answer.setFont(new Font("맑은고딕", Font.BOLD, 20));
		add(answer);
		answer.setVisible(false);
		
		final Book finalB = b;

		btnWrong.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				answer.setVisible(true);
				
				int Quiz = 3; //문제 개수
				//int rightNum = 0; //정답 개수 체크 
				String userAnswer = "X";
				if(userAnswer.equals(finalB.getAnswer1())) {
					rightNum1++;
				}
				System.out.println(rightNum1);
				
			}
		});
		
		btnRight.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				answer.setVisible(true);
				
				int Quiz = 3; //문제 개수
				//int rightNum = 0; //정답 개수 체크 
				String userAnswer = "O";
				if(userAnswer.equals(finalB.getAnswer1())) {
					rightNum1++;
				}
				System.out.println(rightNum1);
			}
		});
		
		btnQuiz2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				FrameBase.getInstance(new FrameQuiz2(finalB));
			}
		});
		
		btnQuiz3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				FrameBase.getInstance(new FrameQuiz3(finalB));
			}
		});
	
    
	}
}