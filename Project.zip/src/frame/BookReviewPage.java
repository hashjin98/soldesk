package frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BookReviewPage extends JPanel {
	JLabel centertitle, titleLabel, authorLabel;
	JTextArea reviewArea;
	JButton saveButton, viewButton, backButton;
	ImageIcon arrowIcon;

	public BookReviewPage(Book b) {
		Color bgc = new Color(255, 241, 137);
		setBackground(new Color(255, 241, 137));
		setLayout(null);
		setSize(600, 800);

		int width = 600; // initial panel width
		int height = 800; // initial panel height

		// Center Title Label
		centertitle = new JLabel("독후감");
		centertitle.setFont(new Font("맑은 고딕", Font.BOLD, 50));
		centertitle.setOpaque(true);
		centertitle.setBackground(new Color(184, 119, 249));
		centertitle.setHorizontalAlignment(SwingConstants.CENTER);
		centertitle.setBounds(width / 5, 20, width * 3 / 5, 60);
		add(centertitle);

		//뒤로가기
		ImageIcon image2 = new ImageIcon("./src/back.png");
		Image img12 = image2.getImage();
		Image updateImg12 = img12.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		ImageIcon updateIcon12 = new ImageIcon(updateImg12);
		JButton btnBack = new JButton(image2);
		btnBack.setIcon(updateIcon12);
		btnBack.setBorderPainted(false);
		btnBack.setBackground(bgc);
		btnBack.setBounds(0, 10, 50, 50);
		add(btnBack);

		btnBack.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (b.getBookName() == "무지개 물고기" || b.getBookName() == "흥부와 놀부" || b.getBookName() == "아기돼지 삼형제"
						|| b.getBookName() == "누가 내 머리에 똥 쌌어?") {

					FrameBase.getInstance(new FrameBookSelect1());
				} else {
					FrameBase.getInstance(new FrameBookSelect2());
				}
			}
		});

		// Title Label
		titleLabel = new JLabel("제목: " + b.getBookName());
		titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
		titleLabel.setBounds(width / 10, height * 3 / 20, width / 2, height / 10);
		add(titleLabel);

		// Author Label
		authorLabel = new JLabel("저자: " + b.getBookPub());
		authorLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
		authorLabel.setBounds(width / 10, height * 2 / 10 + 10, width / 2, height / 10);
		add(authorLabel);

		// Review Area
		reviewArea = new JTextArea("독후감 예시 123456789123456789");
		reviewArea.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
		reviewArea.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (reviewArea.getText().equals("독후감 예시 123456789123456789")) {
					reviewArea.setText("");
				}
			}
		});
		reviewArea.setBounds(width / 10, height * 3 / 10, width * 8 / 10, height / 2);
		add(reviewArea);

		// Save Button
		saveButton = new JButton("저장");
		saveButton.setFont(new Font("맑은 고딕", Font.BOLD, 16));
		saveButton.setBackground(new Color(184, 119, 249));
		saveButton.setBounds((int) (width * 5.6 / 10), height * 8 / 10 + 10, width / 3, height / 10);
		add(saveButton);

		// View Button
		viewButton = new JButton("내가 쓴 독후감 보기");
		viewButton.setFont(new Font("맑은 고딕", Font.BOLD, 16));
		viewButton.setBackground(new Color(184, 119, 249));
		viewButton.setBounds(width / 10, height * 8 / 10 + 10, width / 3, height / 10);
		add(viewButton);

		viewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});

		// 저장 버튼
		saveButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Display a file save dialog
				JFileChooser fileChooser = new JFileChooser();
				int returnValue = fileChooser.showSaveDialog(null);

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					// Get the selected file
					String filePath = fileChooser.getSelectedFile().getAbsolutePath();

					// Get the review text
					String reviewText = reviewArea.getText();

					// Write the review text to the selected file
					try {
						BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
						writer.write(reviewText);
						writer.close();
						JOptionPane.showMessageDialog(null, "독후감이 저장되었습니다.");
					} catch (IOException ex) {
						JOptionPane.showMessageDialog(null, "독후감을 저장하는 중에 오류가 발생했습니다.");
					}
				}
			}
		});
	}
}
