package frame;

import java.util.ArrayList;


public class BookDAO {
	private static ArrayList<Book> list1;
	private static ArrayList<Book> list2;
	// private static ArrayList<Book> list3;
	// private static ArrayList<Quiz> list4;

	public BookDAO() {

		if (list1 == null) {
			init1();
		}

		if (list2 == null) {
			init2();
		}
	}

	private void init1() {

		list1 = new ArrayList<Book>();

		list1.add(new Book("무지개 물고기", "시공주니어", "마르쿠스 피스터",
				"바닷속에 알록달록 무지개빛깔 비늘을 가진 물고기가 있다!\r\n" + "이 물고기에게 고민이 있다는데 무엇일까?"));

		list1.add(new Book("흥부와 놀부", "지경사", "강원희", "가난한 동생 흥부와 부잣집 형인 놀부\r\n" + "이들은 같은 부모 밑에서 태어났건만 어쩌다 이렇게?!"));

		list1.add(new Book("누가 내 머리에 똥 쌌어?", "사계절", "베르너 훌츠바르트", "누군가 두더지의 머리 위에 똥을 쌌다! 과연 범인은 누구일까?!"));

		list1.add(new Book("아기돼지 삼형제", "애플비북스", "이지수", "집에서 독립했지만 바깥은 위험하다! 아기돼지 삼형제는 어떻게 바깥의 위험으로부터 자신의 몸을 지킬 것인가!"));
	} // ini1() 8~10세 도서

	private void init2() {

		list2 = new ArrayList<Book>();

		list2.add(new Book("어린왕자", "열린책들", "앙투안 드 생택쥐페리",
				"어린 왕자가 겪은 다양한 별들의 모험!\r\n" + "이 책에는 여우와의 일화가 가장 유명하다는데..\r\n" + "무슨 이야기일까?"));

		list2.add(new Book("책 먹는 여우", "주니어 김영사", "프란치스카 비어만",
				"책이 너무너무 좋은 여우 아저씨.\r\n" + "이 아저씨는 책을 너무 좋아한 나머지 감옥까지 간다구!?"));

		list2.add(new Book("이상한 나라의 앨리스", "연초록", "루이스 캐럴", "앨리스가 겪는 기묘한 모험!\r\n" + "어떻게 토끼가 말을?!"));

		list2.add(new Book("아낌없이 주는 나무", "시공주니어", "쉘 실버스타인", "나무와 소년의 인생 이야기!\r\n" + "이 책의 진짜 의미는 무엇일까 생각해보자."));
	} // init2() 11~13세 도서

	public Book searchBook1(String name) {

		for (int i = 0; i < list1.size(); i++) {

			if (list1.get(i).getBookName().equals(name)) {

				return list1.get(i);
			}
		}
		return null;
	}

	public Book searchBook2(String name) {

		for (int i = 0; i < list2.size(); i++) {

			if (list2.get(i).getBookName().equals(name)) {

				return list2.get(i);
			}
		}
		return null;
	}
	

}