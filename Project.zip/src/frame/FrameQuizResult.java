package frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class FrameQuizResult extends JPanel{

	public static int totalNum = FrameQuiz3.rightNum3;
	
	public FrameQuizResult(Book b) {
    	setBackground(new Color(255, 241, 137));
        setLayout(null); 
        setSize(600, 800); 

        for(int i=0; i<8; i++) {
        	if(b.getBookName().equals("무지개 물고기")) {
        		Book bookQ = new Book("무지개 물고기", "<html><br>무지개 물고기는 산호초 아저씨를 <br>찾아갔습니다.<html>",
        		   		 "<html><br>무지개 물고기는 하루에 한 번 <br>무지개를 만듭니다.<html>",
        		   		 "<html><br>무지개 물고기는 친구들에게 <br>비늘을 나눠주었습니다.<html>",
        		   		"X", "X", "O");
        		b = bookQ;
        	}else if(b.getBookName().equals("흥부와 놀부")) {
        		Book bookQ = new Book("흥부와 놀부", "<html><br>놀부는 까마귀 다리를 고쳐주고 <br>박을 얻었습니다.<html>", 
			   "<html><br>흥부의 자식은 1명 입니다.<html>", 
			   "<html><br>흥부는 박을 타서 금은보화를 얻었습니다.<html>", 
			   "X", "X", "O");
        		b = bookQ;
        	}else if(b.getBookName().equals("누가 내 머리에 똥 쌌어?")) {
        		Book bookQ = new Book("누가 내 머리에 똥 쌌어?", "<html><br>이 책의 주인공은 두더지입니다.<html>", 
			   "<html><br>두더지는 머리에 똥 싼 범인을 <br>찾기 위해 뱀에게 물어봤습니다.<html>", 
			   "<html><br>두더지는 파리의 도움으로 <br>똥 싼 범인을 찾게 됩니다.<html>", 
			   "O", "X", "O");
        		b = bookQ;
        	}else if(b.getBookName().equals("아기돼지 삼형제")) {
        		Book bookQ = new Book("아기돼지 삼형제", "<html><br>첫째 돼지는 벽돌로 집을 지었습니다.<html>", 
        				   "<html><br>둘째 돼지의 집을 부순건 코끼리입니다.<html>",
        				   "<html><br>둘째돼지와 셋째돼지는<br> 늑대에게 잡아먹혔니다.<html>",  
        				   "X", "X", "X");
        		b = bookQ;
        	}else if(b.getBookName().equals("어린왕자")) {
        		Book bookQ = new Book("어린왕자", "<html><br>어린왕자는 여우에게 양을 <br>그려달라고 부탁합니다.<html>", 
        				   "<html><br>어린왕자는 가로등을 켜는 사람(점등인)을 <br>바보같다고 놀립니다.<html>", 
        				   "<html><br>장미꽃은 어린왕자를 대하는 것에 <br>서툴러했습니다.<html>", 
        				   "X", "X", "O");
        		b = bookQ;
        	}else if(b.getBookName().equals("책 먹는 여우")) {
        		Book bookQ = new Book("책 먹는 여우", "<html><br>여우 아저씨는 책을 먹는걸 좋아합니다.<html>", 
        				   "<html><br>여우 아저씨는 도서관 책을 먹어서 <br>사람들에게 칭찬을 들었습니다.<html>", 
        				   "<html><br>여우 아저씨는 베스트셀러 작가가 <br>되는게 꿈이었습니다.<html>", 
        				   "O", "X", "X");
        		b = bookQ;
        	}else if(b.getBookName().equals("이상한 나라의 앨리스")) {
        		Book bookQ = new Book("이상한 나라의 앨리스", "<html><br>앨리스가 토끼굴로 떨어지게 된 <br>계기는 앨리스의 꿈이었다.<html>", 
        				   "<html><br>이상한 나라의 여왕이 좋아하는 <br>카드 게임은 포커입니다.<html>", 
        				   "<html><br>앨리스가 이상한 나라에서 크기를 <br>조절할 수 있는 물건은 초콜릿입니다.<html>", 
        				   "O", "O", "X");
        		b = bookQ;
        	}else if(b.getBookName().equals("아낌없이 주는 나무")) {
        		Book bookQ = new Book("아낌없이 주는 나무", "<html><br>소년은 나무의 사과를 팔아 <br>돈을 벌었습니다.<html>", 
        				   "<html><br>소년은 나무 그네 타는 것을 <br>싫어했습니다.<html>", 
        				   "<html><br>나무는 소년이 점점 싫어졌습니다.<html>", 
        				   "O", "X", "X");
        		b = bookQ;
        	}
        	
        }
        
        
        
        // RoundedPanel 생성
        RoundedPanel panel1 = new RoundedPanel(new Color(255, 255, 255), b.getQuestion1(), 18);
        panel1.setSize(400, 100); 
        panel1.setLocation(100, 90); 

        add(panel1);
        
        JLabel answer1 = new JLabel("정답:  " + b.getAnswer1());
        answer1.setSize(100, 50);
        answer1.setLocation(260, 190);
		answer1.setFont(new Font("맑은고딕", Font.BOLD, 20));
		add(answer1);
		
		
        // RoundedPanel 생성
        RoundedPanel panel2 = new RoundedPanel(new Color(255, 255, 255), b.getQuestion2(), 18);
        panel2.setSize(400, 100); 
        panel2.setLocation(100, 280); 

        add(panel2);
        
        JLabel answer2 = new JLabel("정답:  " + b.getAnswer2());
        answer2.setSize(100, 50);
        answer2.setLocation(260, 380);
		answer2.setFont(new Font("맑은고딕", Font.BOLD, 20));
		add(answer2);
		
		
        // RoundedPanel 생성
        RoundedPanel panel3 = new RoundedPanel(new Color(255, 255, 255), b.getQuestion3(), 18);
        panel3.setSize(400, 100); 
        panel3.setLocation(100, 470); 

        add(panel3);
        
        JLabel answer3 = new JLabel("정답:  " + b.getAnswer3());
        answer3.setSize(100, 50);
        answer3.setLocation(260, 565);
		answer3.setFont(new Font("맑은고딕", Font.BOLD, 20));
		add(answer3);
		
		JLabel result = new JLabel("맞은 개수:  " + totalNum + "/" + "3");
		result.setSize(200, 50);
		result.setLocation(400, 605);
		result.setFont(new Font("맑은고딕", Font.BOLD, 20));
		add(result);
		
		RoundedButton back = new RoundedButton("책으로 돌아가기");
		back.setSize(300, 50);
		back.setLocation((int)getSize().getWidth()/2 - 160, 675);
		back.setFont(new Font("나눔스퀘어OTF Bold", Font.BOLD, 22));
		add(back);
		
		back.addActionListener(new ActionListener() {
			
		
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//FrameBase.getInstance(new FrameBookInformation(b));
				
			}
		});
	}
}
