package frame;

public class MemberToken {
	public static String tokenID;

	public static String getTokenID() {
		return tokenID;
	}

	public void setTokenID(String tokenID) {
		this.tokenID = tokenID;
	}

}
