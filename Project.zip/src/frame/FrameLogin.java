package frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class FrameLogin extends JPanel {

	static String filename = "회원명단.txt";
	
	public FrameLogin() {
		//this.frameLoginPanel = homePanel;

		// JPanel 구조
		setBackground(new Color(255, 241, 137));
		setLayout(null);
		setSize(600, 800);

		// 아이디, 비번 입력창
		JLabel labelID = new JLabel("ID");
		JLabel labelPW = new JLabel("PW");
		JTextField tfID = new JTextField(10);
		JPasswordField tfPW = new JPasswordField(10);

		labelID.setSize(300, 50);
		labelID.setLocation(getWidth() / 5, 310);
		labelID.setFont(new Font("맑은고딕", Font.BOLD, 20));

		labelPW.setSize(300, 50);
		labelPW.setLocation(getWidth() / 5, 380);
		labelPW.setFont(new Font("맑은고딕", Font.BOLD, 20));

		tfID.setSize(300, 50);
		tfID.setLocation(getWidth() / 6 + 70, 310);
		tfID.setFont(new Font("맑은고딕", Font.BOLD, 20));

		tfPW.setSize(300, 50);
		tfPW.setLocation(getWidth() / 6 + 70, 380);
		tfPW.setFont(new Font("맑은고딕", Font.BOLD, 20));
		tfPW.setEchoChar('*');

		add(labelID);
		add(labelPW);
		add(tfID);
		add(tfPW);
		
		RoundedButton btnLogin = new RoundedButton("로그인");
		RoundedButton btnJoin = new RoundedButton("회원가입");
		

		btnLogin.setSize(300, 40);
		btnLogin.setLocation(getWidth() / 4 - 5, 470);
		btnLogin.setFont(new Font("나눔스퀘어OTF Bold", Font.BOLD, 22));

		btnJoin.setSize(300, 40);
		btnJoin.setLocation((int) btnLogin.getLocation().getX(), (int) btnLogin.getLocation().getY() + 70);

		btnJoin.setFont(new Font("나눔스퀘어OTF Bold", Font.BOLD, 22));

		add(btnLogin);
		add(btnJoin);

		btnJoin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				FrameJoin frameJoin = new FrameJoin();
		        
		        JFrame frame = (JFrame) FrameLogin.this.getTopLevelAncestor();
		        frame.getContentPane().removeAll();
		        
		        frame.getContentPane().add(frameJoin);
		        
		        frame.revalidate();
		        frame.repaint();
			}
		});
		
		btnLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				MemberController cm = new MemberController();
				ArrayList<Member> memberArr = cm.readFile(filename);
				MemberList memberList = new MemberList();
				
				for(int i=0; i<memberArr.size(); i++) {
					memberList.addMember(memberArr.get(i));
				}
				
				String id = tfID.getText();
				String idCheck = memberList.loginMember(id);
				
				if(idCheck.isEmpty()) {
					JOptionPane.showMessageDialog(null, "아이디를 확인해주세요.");
				} else {
					if(idCheck.equals(new String(tfPW.getPassword()))) {
						MemberToken.tokenID = id;
						JOptionPane.showMessageDialog(null, id + "님, 환영합니다!");
						FrameSelectAge frameSelectAge = new FrameSelectAge();
				        
				        JFrame frame = (JFrame) FrameLogin.this.getTopLevelAncestor();
				        frame.getContentPane().removeAll();
				        
				        frame.getContentPane().add(frameSelectAge);
				        
				        frame.revalidate();
				        frame.repaint();
					} else {
						JOptionPane.showMessageDialog(null, "비밀번호를 확인해주세요.");
					}
				}
				
			}
		});

	}// 생성자
	
}
