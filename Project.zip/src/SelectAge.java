import javax.swing.*;

import frame.RoundedButton;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class SelectAge {
    public static void main(String[] args) {
        Frame f = new Frame("유책(나이 선택)");
        f.setBounds(200, 200, 400, 400);
        f.setLayout(null);
        f.setBackground(new Color(255, 241, 137));

        Font font = new Font(Font.SANS_SERIF, Font.PLAIN, 18);

        // 이미지 파일 경로
        String imagePath = "./src/lower.png";

        // 이미지 표시를 위한 JLabel 생성
        JLabel imageLabel = new JLabel();
        imageLabel.setBounds(100, 10, 200, 70); // 이미지 표시 위치 및 크기 조절

        try {
            BufferedImage image = ImageIO.read(new File(imagePath)); // 이미지 파일 읽기
            ImageIcon icon = new ImageIcon(image); // 이미지 아이콘 생성
            imageLabel.setIcon(icon); // 레이블에 이미지 아이콘 설정
        } catch (IOException e) {
            e.printStackTrace();
        }

        RoundedButton btnLower = new RoundedButton("8~10세");
        btnLower.setBounds(70, 190, 100, 50);
        btnLower.setBackground(new Color(184, 119, 249));
        btnLower.setFont(font);

        RoundedButton btnHigher = new RoundedButton("11~13세");
        btnHigher.setBounds(70, 190, 100, 50);
        btnHigher.setLocation(btnLower.getX() + btnLower.getWidth() + 60, btnLower.getY());
        btnHigher.setBackground(new Color(184, 119, 249));
        btnHigher.setFont(font);

        f.add(imageLabel); // 이미지 레이블을 프레임에 추가
        f.add(btnLower);
        f.add(btnHigher);

        f.setVisible(true);
    }
}