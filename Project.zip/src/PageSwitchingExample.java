import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class PageSwitchingExample {
    private static JPanel cardPanel;
    private static CardLayout cardLayout;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Page Switching Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        // 페이지 1
        JPanel page1 = new JPanel();
        page1.setBackground(Color.YELLOW);
        page1.add(new JLabel("페이지 1"));

        // 페이지 2
        JPanel page2 = new JPanel();
        page2.setBackground(Color.CYAN);
        page2.add(new JLabel("페이지 2"));

        // 페이지 패널을 추가
        cardPanel.add(page1, "Page 1");
        cardPanel.add(page2, "Page 2");

        // 커스텀 둥근 테두리 버튼 1
        RoundedBorderButton roundedButton1 = new RoundedBorderButton("버튼 1", "Page 1");
        roundedButton1.addActionListener(new PageSwitchListener());
        page1.add(roundedButton1);

        // 커스텀 둥근 테두리 버튼 2
        RoundedBorderButton roundedButton2 = new RoundedBorderButton("버튼 2", "Page 2");
        roundedButton2.addActionListener(new PageSwitchListener());
        page2.add(roundedButton2);

        frame.add(cardPanel);
        frame.setVisible(true);
    }

    static class RoundedBorderButton extends JButton {
        private int arcRadius = 15; // 테두리의 둥근 정도를 조절할 반지름
        private String targetPage;

        public RoundedBorderButton(String text, String targetPage) {
            super(text);
            this.targetPage = targetPage;

            // 버튼의 룩 앤 필(Look and Feel)을 커스텀
            setBorderPainted(false);
            setContentAreaFilled(false);
            setFocusPainted(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            if (getModel().isArmed()) {
                g.setColor(Color.lightGray); // 클릭된 상태에서 배경 색 설정
            } else {
                g.setColor(getBackground());
            }

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();

            RoundRectangle2D rect = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, arcRadius, arcRadius);
            g2.fill(rect);
            super.paintComponent(g);
        }

        public String getTargetPage() {
            return targetPage;
        }
    }

    static class PageSwitchListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            RoundedBorderButton button = (RoundedBorderButton) e.getSource();
            cardLayout.show(cardPanel, button.getTargetPage());
        }
    }
}