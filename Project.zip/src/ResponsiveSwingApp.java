import javax.swing.*;
import java.awt.*;

public class ResponsiveSwingApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Responsive Swing App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(60, 60, 60, 60); // 버튼 간의 간격 설정

        JButton button1 = new JButton("8~10세");
        JButton button2 = new JButton("11~13세");
        
        constraints.gridx = 0;
        constraints.gridy = 3;
        panel.add(button1, constraints);

        constraints.gridx = 1;
        constraints.gridy = 4;
        panel.add(button2, constraints);

        frame.add(panel);
        frame.setSize(800, 600); // 원하는 화면 크기로 설정
        frame.setVisible(true);
    }
}